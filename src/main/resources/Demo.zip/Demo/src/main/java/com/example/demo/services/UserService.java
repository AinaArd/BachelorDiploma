package com.example.demo.services;

import com.example.demo.dto.UserDto;
import com.example.demo.models.User;

public interface UserService {
    UserDto getUserDtoById(Long userId);

    ${} findUserById(Long userId);

    ${} signUp(UserDto userDto);

    ${} signIn(UserDto userDto);
}
