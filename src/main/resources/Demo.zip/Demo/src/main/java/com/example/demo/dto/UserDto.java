package com.example.demo.dto;

import com.example.demo.models.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class UserDto {
    private Long id;
    private String ${};
    private String ${};

    public static UserDto from(User user) {
        return UserDto.builder()
                .id(user.getId())
                .build();
    }

    public static UserDto empty() {
        return UserDto.builder().build();
    }
}
